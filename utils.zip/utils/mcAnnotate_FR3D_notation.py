import os
import sys
import copy

# file_name = sys.argv[1]
# fo = open(file_name,'r')
# a = fo.readlines()
# a = [x for x in a if (('PDB Code' not in x) and ('num' not in x) and (x!='\n')) ]

pu = ['A','G']
py = ['C','U']

def mcAnnotate_FR3D_notation(nucs,faces):
	mcAnnotate_notation = ''
	FR3D_notation = ''
	if(faces=='alpha-alpha'): #ALPHA_ALPHA FACE
		if(nucs[0] in pu and nucs[1] in pu):
			mcAnnotate_notation = '><\tinward'
			FR3D_notation = 'S33'
		elif(nucs[0] in py and nucs[1] in py):
			mcAnnotate_notation = '<>\toutward'
			FR3D_notation = 'S55'
		elif(nucs[0] in pu and nucs[1] in py):
			mcAnnotate_notation = '>>\tupward'
			FR3D_notation = 'S35'
		elif(nucs[0] in py and nucs[1] in pu):
			mcAnnotate_notation = '<<\tdownward'
			FR3D_notation = 'S53'
	elif(faces=='alpha-beta'): #ALPHA_BETA FACE
		if(nucs[0] in pu and nucs[1] in pu):
			mcAnnotate_notation = '>>\tupward'
			FR3D_notation = 'S35'
		elif(nucs[0] in py and nucs[1] in py):
			if(nucs[0]==nucs[1]):
				mcAnnotate_notation = '>>\tupward'
				FR3D_notation = 'S35'
			else:
				mcAnnotate_notation = '<<\tdownward'
				FR3D_notation = 'S53'
		elif(nucs[0] in pu and nucs[1] in py):
			mcAnnotate_notation = '><\tinward'
			FR3D_notation = 'S33'
		elif(nucs[0] in py and nucs[1] in pu):
			mcAnnotate_notation = '<>\toutward'
			FR3D_notation = 'S55'
	elif(faces=='beta-alpha'): #BETA ALPHA FACE
		if(nucs[0] in pu and nucs[1] in pu):
			if(nucs[0]==nucs[1]):
				mcAnnotate_notation = '>>\tupward'	
				FR3D_notation = 'S35'
			else:
				mcAnnotate_notation = '<<\tdownward'
				FR3D_notation = 'S53'
		if(nucs[0] in py and nucs[1] in py):
			mcAnnotate_notation = '>>\tupward'
			FR3D_notation = 'S35'
		elif(nucs[0] in pu and nucs[1] in py):
			mcAnnotate_notation = '<>\toutward'
			FR3D_notation = 'S55'
		elif(nucs[0] in py and nucs[1] in pu):
			mcAnnotate_notation = '><\tinward'
			FR3D_notation = 'S33'
	elif(faces=='beta-beta'): #BETA BETA FACE
		if(nucs[0] in pu and nucs[1] in pu):
			mcAnnotate_notation = '<>\toutward'
			FR3D_notation = 'S55'
		elif(nucs[0] in py and nucs[1] in py):
			mcAnnotate_notation = '><\tinward'
			FR3D_notation = 'S33'
		elif(nucs[0] in pu and nucs[1] in py):
			mcAnnotate_notation = '<<\tdownward'
			FR3D_notation = 'S53'
		elif(nucs[0] in py and nucs[1] in pu):
			mcAnnotate_notation = '>>\tupward'
			FR3D_notation = 'S35'
	annotation = [mcAnnotate_notation,FR3D_notation]
	return annotation