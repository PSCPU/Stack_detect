import os
import sys

def convert_modified_bases(nucs):
	for nuc in ['A','C','G','U']:
		if(nuc in nucs[0]):
			nucs[0] = nuc
		if(nuc in nucs[1]):
			nucs[1] = nuc
	return nucs
