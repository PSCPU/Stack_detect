import sys
import math
import numpy as np

def make_vector(v): # Convert a list of values to numpy array data type
	# temp = np.array(map(float,v))
	temp = np.array([float(x) for x in v])
	return temp

def normalize(v): # Normalize a vector. ||V|| = V/|V|
	v = v/(np.sqrt(np.dot(v,v)))
	return v

def angle(v1,v2):	# Calculate angle between two vectors, (ax+cy+ez) and (bx+dy+fz)
	v = np.dot(v1,v2)
	v = round(v,3) # We round-off the values to 3 decimal places to avoid math domain error in acos
	ang = math.degrees(math.acos(v))
	return ang

"""
Creating a Rotaion matrix along a given axis by a given angle.
Link: https://en.wikipedia.org/wiki/Rotation_matrix#Rotation_matrix_from_axis_and_angle
"""
def create_rot_mat(u,t): 
	tensor = np.dot(u.reshape(3,1),u.reshape(1,3))

	cp_mat = np.array([[0,-u[2],u[1]],[u[2],0,-u[0]],[-u[1],u[0],0]])

	I = np.identity(3)
	c = math.cos(math.radians(t))
	s = math.sin(math.radians(t))
	r = (c*I) + (s*cp_mat) + ((1-c)*tensor)
	return r

"""
Orientation matrix is the 3x3 matrix whose columns give the direction cosine of the x, y and z axes of the plane.
"""
def create_ori_mat(p):
	x = p['xaxis']
	y = p['yaxis']
	z = p['n']
	m = np.array([x,y,z])
	m = m.transpose()
	return m

"""
p1, p2 are the two given planes. pmst is the mid-step triad.
p1(p2) contains: x,y,z-axis; center; atom coordinates.
pmst contains: roll-tilt angle(rt); hinge axis; center

t1, t2 are the orientation matrix of the two given planes respectively.
tmst is the orientation matrix of the mst.

twist: Angle between the y-axis of the given planes after all the transformations.
phi: Minimum angle between the hinge axis and the y-axis of the mst.
rho and tau: Angle of rotation along y-axis and x-axis respectively. Calculated with the help of Roll-Tilt Approximation.
D: [D(x) D(y) D(z)] i.e. shift, slide and rise respectively. 
"""
def base_step(p1,p2):
	pmst={}

	for key in list(p1.keys()):
		p1[key] = make_vector(p1[key])

	for key in list(p2.keys()):
		p2[key] = make_vector(p2[key])

	pmst['rt'] = angle(p1['n'],p2['n']) # Minimum angle between two normals is the roll-tilt angle. 

	if(pmst['rt']>180-pmst['rt']): # If the normals are in opposite direction then invert one of the normals and its corresponding x-axis to maintain the signs.
		pmst['rt'] = min(180-pmst['rt'],pmst['rt'])	
		p2['n'] = -1*p2['n']
		p2['xaxis'] = -1*p2['xaxis']

	pmst['hinge'] = normalize(np.cross(p1['n'],p2['n'])) # Axis along which the two given planes will be rotated is the hinge axis.

	t1 = create_ori_mat(p1)
	t2 = create_ori_mat(p2)

	rotation_matrix = create_rot_mat(pmst['hinge'],pmst['rt']/2.0)
	t1 = np.matmul(rotation_matrix,t1) # Rotating t1 with positive theta

	rotation_matrix = create_rot_mat(pmst['hinge'],-1*pmst['rt']/2.0)
	t2 = np.matmul(rotation_matrix,t2) # Rotating t2 with negative theta


	tmst = (t1+t2)/2 # Calculating tmst i.e. the average of t1 and t2.
	pmst['center'] = (p1['center']+p2['center'])/2 # Calculating center of mst i.e. average of the the two centers.

	"""
	Calcualting the parameters
	"""

	twist = angle(t1.transpose()[1],t2.transpose()[1]) 
	if(np.dot(np.cross(normalize(t1.transpose()[1]),normalize(t2.transpose()[1])),t1.transpose()[2])<0): #Check for sign of twist.
		twist = -1*twist

	phi = angle(pmst['hinge'],tmst.transpose()[1])
	phi = min(180-phi,phi)
	rho = pmst['rt']*math.cos(math.radians(phi))
	tau = pmst['rt']*math.sin(math.radians(phi))
	D = np.matmul((p2['center'] - p1['center']),tmst)
	
	return {'twist':format(twist,'.4f'), 'phi': format(phi,'.4f'), 'roll': format(rho,'.4f'), 'tilt': format(tau,'.4f'), "shift":format(abs(D[0]),'.4f'), "slide":format(abs(D[1]),'.4f'),"rise":format(abs(D[2]),'.4f')}